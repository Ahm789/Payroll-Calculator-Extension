// Helper: Get current UK tax year
function getCurrentTaxYear() {
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth() + 1; // Jan = 0
    return month >= 4 ? `${year}-${year + 1}` : `${year - 1}-${year}`;
}
function formatCycle(cycle) {
    if (!cycle) return "";

    const map = {
        weekly: "Weekly",
        biweekly: "Bi-weekly",
        fourweekly: "Four-weekly",
        monthly: "Monthly"
    };

    return map[cycle] || cycle;
}

// Helper: Determine tax year from a date string
function getTaxYearFromDate(dateStr) {
    const date = new Date(dateStr);
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    return month >= 4 ? `${year}-${year + 1}` : `${year - 1}-${year}`;
}

// Helper: Calculate totals for a tax year
function calculateTaxYearTotals(taxYearData) {
    let totalGross = 0, totalTax = 0, totalNI = 0, totalTakeHome = 0;

    Object.values(taxYearData).forEach(entry => {
        totalGross += entry.gross;
        totalTax += entry.incomeTax;
        totalNI += entry.ni;
        totalTakeHome += entry.takeHome;
    });

    return { totalGross, totalTax, totalNI, totalTakeHome };
}

function renderSavedData(selectedTaxYear = null) {
    const container = document.getElementById("container");
    container.innerHTML = "";

    chrome.storage.local.get(["data"], (res) => {
        const data = res.data || {};
        const entries = Object.entries(data)
            .filter(([date, entry]) => selectedTaxYear ? getTaxYearFromDate(date) === selectedTaxYear : true)
            .sort(([a], [b]) => new Date(a) - new Date(b));

        if (!entries.length) {
            container.textContent = "No pay data for this tax year.";
            return;
        }

        // Tax year summary panel
        const taxYearData = Object.fromEntries(entries);
        const totals = calculateTaxYearTotals(taxYearData);
        const summaryCard = document.getElementById("summaryCard");
        if (summaryCard) {
            document.getElementById('taxYearSummary').textContent =
                `${selectedTaxYear || getCurrentTaxYear()} Summary`;
            const p = summaryCard.querySelectorAll('p span');
            p[0].textContent = `£${totals.totalGross.toFixed(2)}`;
            p[1].textContent = `£${totals.totalTax.toFixed(2)}`;
            p[2].textContent = `£${totals.totalNI.toFixed(2)}`;
            p[3].textContent = `£${totals.totalTakeHome.toFixed(2)}`;
        }

        // Group by month
        const months = {};
        entries.forEach(([date, entry]) => {
            const d = new Date(date);
            const key = `${d.getFullYear()}-${d.getMonth() + 1}`;
            if (!months[key]) months[key] = [];
            months[key].push([date, entry]);
        });

        const monthNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];

        Object.keys(months).forEach(monthKey => {
            const list = months[monthKey];
            const firstDate = new Date(list[0][0]);
            const monthNum = firstDate.getMonth();
            const yearNum = firstDate.getFullYear();

            // Month header
            const header = document.createElement("h2");
            header.textContent = `${monthNames[monthNum]} ${yearNum}`;
            header.style.marginTop = "25px";
            container.appendChild(header);

            // Multiple entries → summary + expand
            if (list.length > 1) {
                // Assume list = [[date, entry], ...] for the month
                let totalGross = 0, totalTax = 0, totalNI = 0, totalTakeHome = 0;
                list.forEach(([_, e]) => {
                    totalGross += e.gross;
                    totalTax += e.incomeTax;
                    totalNI += e.ni;
                    totalTakeHome += e.takeHome;
                });

                // Month summary card
                const summaryCard = document.createElement("div");
                summaryCard.className = "pay-card";
                summaryCard.innerHTML = `
                    <div class="main-info">
                        <strong>Summary:</strong> Total Gross £${totalGross.toFixed(2)}, 
                        Tax £${totalTax.toFixed(2)}, NI £${totalNI.toFixed(2)}, 
                        Take-home £${totalTakeHome.toFixed(2)}
                        <button class="toggle-details" style="margin-left:10px; cursor:pointer;">+</button>
                    </div>
                    <div class="details" style="display:none; margin-top:5px; padding-left:10px;"></div>
                `;

                container.appendChild(summaryCard);

                const detailsDiv = summaryCard.querySelector(".details");
                const toggleBtn = summaryCard.querySelector(".toggle-details");

                // Toggle month details
                toggleBtn.addEventListener("click", () => {
                    const isHidden = detailsDiv.style.display === "none";
                    detailsDiv.style.display = isHidden ? "block" : "none";
                    toggleBtn.textContent = isHidden ? "−" : "+";
                });

                // Add each entry inside the month details
                list.forEach(([date, entry]) => {
                    const entryCard = document.createElement("div");
                    entryCard.className = "pay-card";
                    entryCard.style.margin = "5px 0";

                    const entryInfo = document.createElement("div");
                    entryInfo.className = "main-info";
                    entryInfo.textContent = `${date} - ${formatCycle(entry.payCycle)} - Gross £${entry.gross}, Tax £${entry.incomeTax}, NI £${entry.ni}, Take-home £${entry.takeHome}`;
                    entryCard.appendChild(entryInfo);

                    const ul = document.createElement("ul");
                    ul.className = "shift-list";

                    // SHIFTS
                    if (entry.shifts && entry.shifts.length) {
                        if (entry.shifts.length >= 3) {
                            const shiftContainer = document.createElement("li");
                            shiftContainer.className = "shift-item";

                            const mainShiftInfo = document.createElement("div");
                            mainShiftInfo.className = "main-info";
                            mainShiftInfo.style.cursor = "pointer";

                            let totalShiftHours = 0, totalShiftPay = 0;
                            entry.shifts.forEach(s => { totalShiftHours += s.hours; totalShiftPay += s.gross; });

                            mainShiftInfo.innerHTML = `
                                <strong>Shifts Total:</strong> ${totalShiftHours}h → £${totalShiftPay.toFixed(2)}
                                <button class="toggle-details" style="margin-left:10px; cursor:pointer;">+</button>
                            `;

                            const shiftDetails = document.createElement("div");
                            shiftDetails.className = "details";
                            shiftDetails.style.display = "none";
                            shiftDetails.style.marginTop = "5px";
                            shiftDetails.style.paddingLeft = "10px";

                            entry.shifts.forEach((s, i) => {
                                const li = document.createElement("li");
                                li.className = "shift-item";
                                li.textContent = `Shift ${i + 1}: ${s.hours}h , £${s.rate}/hr → Gross £${s.gross}`;
                                shiftDetails.appendChild(li);
                            });

                            const shiftToggle = mainShiftInfo.querySelector(".toggle-details");
                            shiftToggle.addEventListener("click", () => {
                                const isHidden = shiftDetails.style.display === "none";
                                shiftDetails.style.display = isHidden ? "block" : "none";
                                shiftToggle.textContent = isHidden ? "−" : "+";
                            });

                            shiftContainer.appendChild(mainShiftInfo);
                            shiftContainer.appendChild(shiftDetails);
                            ul.appendChild(shiftContainer);
                        } else {
                            entry.shifts.forEach((s, i) => {
                                const li = document.createElement("li");
                                li.className = "shift-item";
                                li.textContent = `Shift ${i + 1}: ${s.hours}h , £${s.rate}/hr → Gross £${s.gross}`;
                                ul.appendChild(li);
                            });
                        }
                    }

                    // HOLIDAYS
                    if (entry.holidays && entry.holidays.records && entry.holidays.records.length) {
                        const holidayContainer = document.createElement("li");
                        holidayContainer.className = "holiday-item";

                        const mainHoliday = document.createElement("div");
                        mainHoliday.className = "main-info";
                        mainHoliday.style.cursor = "pointer";
                        mainHoliday.innerHTML = `
                            <strong>Holiday Total:</strong> ${entry.holidays.totalHours}h → £${entry.holidays.totalPay.toFixed(2)}
                            <button class="toggle-details" style="margin-left:10px; cursor:pointer;">+</button>
                        `;

                        const holidayDetails = document.createElement("div");
                        holidayDetails.className = "details";
                        holidayDetails.style.display = "none";
                        holidayDetails.style.marginTop = "5px";
                        holidayDetails.style.paddingLeft = "10px";

                        entry.holidays.records.forEach((h, i) => {
                            const li = document.createElement("li");
                            li.className = "holiday-item";
                            li.textContent = `Holiday ${i + 1}: ${h.hours}h , £${h.rate}/hr → Gross £${h.pay.toFixed(2)}`;
                            holidayDetails.appendChild(li);
                        });

                        const holidayToggle = mainHoliday.querySelector(".toggle-details");
                        holidayToggle.addEventListener("click", () => {
                            const isHidden = holidayDetails.style.display === "none";
                            holidayDetails.style.display = isHidden ? "block" : "none";
                            holidayToggle.textContent = isHidden ? "−" : "+";
                        });

                        holidayContainer.appendChild(mainHoliday);
                        holidayContainer.appendChild(holidayDetails);
                        ul.appendChild(holidayContainer);
                    }

                    // OTHERS
                    if ((entry.extraDeductions || entry.extraTaxFree) && (entry.extraDeductions + entry.extraTaxFree > 0)) {
                        const li = document.createElement("li");
                        li.className = "other-item";
                        li.textContent = `Other: £${entry.extraDeductions || 0} deductions, £${entry.extraTaxFree || 0} tax-free`;
                        ul.appendChild(li);
                    }

                    if (ul.children.length) entryCard.appendChild(ul);
                    detailsDiv.appendChild(entryCard);
                });

            } else {
                // Single entry
                const [date, entry] = list[0];
                const card = document.createElement("div");
                card.className = "pay-card";

                const mainInfo = document.createElement("div");
                mainInfo.className = "main-info";
                mainInfo.textContent =
                    `${date} - ${formatCycle(entry.payCycle)} - Gross £${entry.gross}, Tax £${entry.incomeTax}, NI £${entry.ni}, Take-home £${entry.takeHome}`;
                card.appendChild(mainInfo);

                const ul = document.createElement("ul");
                ul.className = "shift-list";

                // Shifts
                if (entry.shifts && entry.shifts.length) {
                    if (entry.shifts.length >= 3) {
                        // Container li for the shifts section
                        const shiftContainer = document.createElement("li");
                        shiftContainer.className = "shift-item"; // keeps CSS

                        // Main info div with toggle
                        const mainInfo = document.createElement("div");
                        mainInfo.className = "main-info";
                        mainInfo.style.cursor = "pointer";

                        // Compute total hours and total pay
                        let totalShiftHours = 0;
                        let totalShiftPay = 0;
                        entry.shifts.forEach(s => {
                            totalShiftHours += s.hours;
                            totalShiftPay += s.gross;
                        });

                        // Add summary text
                        mainInfo.innerHTML = `
                            <strong>Shifts Total:</strong> ${totalShiftHours}h → £${totalShiftPay.toFixed(2)}
                            <button class="toggle-details" style="margin-left:10px; cursor:pointer;">+</button>
                        `;

                        // Details div, hidden initially
                        const detailsDiv = document.createElement("div");
                        detailsDiv.className = "details";
                        detailsDiv.style.display = "none";
                        detailsDiv.style.marginTop = "5px";
                        detailsDiv.style.paddingLeft = "10px";

                        // Add individual shifts inside details
                        entry.shifts.forEach((s, i) => {
                            const li = document.createElement("li");
                            li.textContent = `Shift ${i + 1}: ${s.hours}h , £${s.rate}/hr → Gross £${s.gross}`;
                            li.className = "shift-item"; // keeps styling
                            detailsDiv.appendChild(li);
                        });

                        // Toggle button click
                        const toggleBtn = mainInfo.querySelector(".toggle-details");
                        toggleBtn.addEventListener("click", () => {
                            if (detailsDiv.style.display === "none") {
                                detailsDiv.style.display = "block";
                                toggleBtn.textContent = "−";
                            } else {
                                detailsDiv.style.display = "none";
                                toggleBtn.textContent = "+";
                            }
                        });

                        shiftContainer.appendChild(mainInfo);
                        shiftContainer.appendChild(detailsDiv);
                        ul.appendChild(shiftContainer);
                    } else {
                        // Less than 3 shifts → show normally
                        entry.shifts.forEach((s, i) => {
                            const li = document.createElement("li");
                            li.textContent = `Shift ${i + 1}: ${s.hours}h , £${s.rate}/hr → Gross £${s.gross}`;
                            li.className = "shift-item";
                            ul.appendChild(li);
                        });
                    }
                }


                // Holidays
                if (entry.holidays && entry.holidays.records && entry.holidays.records.length) {
                    // Container li for the holiday section
                    const holidayContainer = document.createElement("li");
                    holidayContainer.className = "holiday-item"; // keeps CSS

                    // Main info div with toggle
                    const mainInfo = document.createElement("div");
                    mainInfo.className = "main-info";
                    mainInfo.style.cursor = "pointer";

                    // Add summary text
                    mainInfo.innerHTML = `
                        <strong>Holiday Total:</strong> ${entry.holidays.totalHours}h → £${entry.holidays.totalPay.toFixed(2)}
                        <button class="toggle-details" style="margin-left:10px; cursor:pointer;">+</button>
                    `;

                    // Details div, hidden initially
                    const detailsDiv = document.createElement("div");
                    detailsDiv.className = "details";
                    detailsDiv.style.display = "none";
                    detailsDiv.style.marginTop = "5px";
                    detailsDiv.style.paddingLeft = "10px";

                    // Add individual holidays inside details
                    entry.holidays.records.forEach((h, i) => {
                        const li = document.createElement("li");
                        li.textContent = `Holiday ${i + 1}: ${h.hours}h , £${h.rate}/hr → Gross £${h.pay.toFixed(2)}`;
                        li.className = "holiday-item"; // keeps styling
                        detailsDiv.appendChild(li);
                    });

                    // Toggle button click
                    const toggleBtn = mainInfo.querySelector(".toggle-details");
                    toggleBtn.addEventListener("click", () => {
                        if (detailsDiv.style.display === "none") {
                            detailsDiv.style.display = "block";
                            toggleBtn.textContent = "−";
                        } else {
                            detailsDiv.style.display = "none";
                            toggleBtn.textContent = "+";
                        }
                    });

                    holidayContainer.appendChild(mainInfo);
                    holidayContainer.appendChild(detailsDiv);
                    ul.appendChild(holidayContainer);
                }
                // Other
                if ((entry.extraDeductions || entry.extraTaxFree) && (entry.extraDeductions + entry.extraTaxFree > 0)) {
                    const li = document.createElement("li");
                    li.className = "other-item"; // <-- class for CSS
                    li.textContent = `Other: £${entry.extraDeductions || 0} deductions, £${entry.extraTaxFree || 0} tax-free`;
                    ul.appendChild(li);
                }


                if (ul.children.length) card.appendChild(ul);
                container.appendChild(card);
            }
        });
    });
}


// Clear data button
document.getElementById("clearDataBtn").addEventListener("click", () => {
    if (confirm("Are you sure you want to clear all saved pay data?")) {
        chrome.storage.local.remove("data", () => {
            alert("Saved pay data cleared.");
            renderSavedData();
        });
    }
});

let monthlyChartVisible = false;

// Show monthly bar chart button
document.getElementById("showMonthlyBtn").addEventListener("click", () => {
    const selector = document.getElementById("taxYearSelector");
    const year = selector ? selector.value : null;

    if (!monthlyChartVisible) {
        // Show monthly bar chart
        renderMonthlyBarChartInContainer(year);
        document.getElementById("showMonthlyBtn").textContent = "Show Pay List";
    } else {
        // Restore the list view
        renderSavedData(year);
        document.getElementById("showMonthlyBtn").textContent = "Show Monthly Bar Chart";
    }

    monthlyChartVisible = !monthlyChartVisible;
});

function renderPayForMonth(selectedTaxYear, month) {
    const container = document.getElementById("container");
    if (!container) return;
    container.innerHTML = "";

    chrome.storage.local.get(["data"], (res) => {
        const data = res.data || {};

        const entries = Object.entries(data)
            .filter(([date, entry]) => {
                const d = new Date(date);
                const entryMonth = d.getMonth() + 1;
                const taxYear = getTaxYearFromDate(date);
                return entryMonth === month && (!selectedTaxYear || taxYear === selectedTaxYear);
            })
            .sort(([a], [b]) => new Date(a) - new Date(b));

        if (!entries.length) {
            container.textContent = "No pay data for this month.";
            return;
        }

        const monthNames = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
        const monthHeader = document.createElement("h2");
        monthHeader.textContent = `${monthNames[month-1]} ${selectedTaxYear || ''} Pay`;
        container.appendChild(monthHeader);

        // Function to render shifts, holidays, and other details inside a card
        const renderEntryDetails = (entry, card) => {
            const ul = document.createElement("ul");
            ul.className = "shift-list";

            // Shifts
            if (entry.shifts && entry.shifts.length) {
                if (entry.shifts.length >= 3) {
                    const shiftContainer = document.createElement("li");
                    shiftContainer.className = "shift-item";

                    const mainInfo = document.createElement("div");
                    mainInfo.className = "main-info";
                    mainInfo.style.cursor = "pointer";

                    let totalShiftHours = 0, totalShiftPay = 0;
                    entry.shifts.forEach(s => {
                        totalShiftHours += s.hours;
                        totalShiftPay += s.gross;
                    });

                    mainInfo.innerHTML = `
                        <strong>Shifts Total:</strong> ${totalShiftHours}h → £${totalShiftPay.toFixed(2)}
                        <button class="toggle-details" style="margin-left:10px; cursor:pointer;">+</button>
                    `;

                    const detailsDiv = document.createElement("div");
                    detailsDiv.className = "details";
                    detailsDiv.style.display = "none";
                    detailsDiv.style.marginTop = "5px";
                    detailsDiv.style.paddingLeft = "10px";

                    entry.shifts.forEach((s, i) => {
                        const li = document.createElement("li");
                        li.textContent = `Shift ${i + 1}: ${s.hours}h , £${s.rate}/hr → Gross £${s.gross}`;
                        li.className = "shift-item";
                        detailsDiv.appendChild(li);
                    });

                    const toggleBtn = mainInfo.querySelector(".toggle-details");
                    toggleBtn.addEventListener("click", () => {
                        if (detailsDiv.style.display === "none") {
                            detailsDiv.style.display = "block";
                            toggleBtn.textContent = "−";
                        } else {
                            detailsDiv.style.display = "none";
                            toggleBtn.textContent = "+";
                        }
                    });

                    shiftContainer.appendChild(mainInfo);
                    shiftContainer.appendChild(detailsDiv);
                    ul.appendChild(shiftContainer);
                } else {
                    entry.shifts.forEach((s, i) => {
                        const li = document.createElement("li");
                        li.textContent = `Shift ${i + 1}: ${s.hours}h , £${s.rate}/hr → Gross £${s.gross}`;
                        li.className = "shift-item";
                        ul.appendChild(li);
                    });
                }
            }

            // Holidays
            if (entry.holidays && entry.holidays.records && entry.holidays.records.length) {
                const holidayContainer = document.createElement("li");
                holidayContainer.className = "holiday-item";

                const mainInfo = document.createElement("div");
                mainInfo.className = "main-info";
                mainInfo.style.cursor = "pointer";

                mainInfo.innerHTML = `
                    <strong>Holiday Total:</strong> ${entry.holidays.totalHours}h → £${entry.holidays.totalPay.toFixed(2)}
                    <button class="toggle-details" style="margin-left:10px; cursor:pointer;">+</button>
                `;

                const detailsDiv = document.createElement("div");
                detailsDiv.className = "details";
                detailsDiv.style.display = "none";
                detailsDiv.style.marginTop = "5px";
                detailsDiv.style.paddingLeft = "10px";

                entry.holidays.records.forEach((h, i) => {
                    const li = document.createElement("li");
                    li.textContent = `Holiday ${i + 1}: ${h.hours}h , £${h.rate}/hr → Gross £${h.pay.toFixed(2)}`;
                    li.className = "holiday-item";
                    detailsDiv.appendChild(li);
                });

                const toggleBtn = mainInfo.querySelector(".toggle-details");
                toggleBtn.addEventListener("click", () => {
                    if (detailsDiv.style.display === "none") {
                        detailsDiv.style.display = "block";
                        toggleBtn.textContent = "−";
                    } else {
                        detailsDiv.style.display = "none";
                        toggleBtn.textContent = "+";
                    }
                });

                holidayContainer.appendChild(mainInfo);
                holidayContainer.appendChild(detailsDiv);
                ul.appendChild(holidayContainer);
            }

            // Other deductions/tax-free
            if ((entry.extraDeductions || entry.extraTaxFree) && (entry.extraDeductions + entry.extraTaxFree > 0)) {
                const li = document.createElement("li");
                li.className = "other-item";
                li.textContent = `Other: £${entry.extraDeductions || 0} deductions, £${entry.extraTaxFree || 0} tax-free`;
                ul.appendChild(li);
            }

            if (ul.children.length) card.appendChild(ul);
        };

        // If multiple entries → summary card with expandable details
        if (entries.length > 1) {
            let totalGross = 0, totalTax = 0, totalNI = 0, totalTakeHome = 0;
            entries.forEach(([_, e]) => {
                totalGross += e.gross;
                totalTax += e.incomeTax;
                totalNI += e.ni;
                totalTakeHome += e.takeHome;
            });

            const summaryCard = document.createElement("div");
            summaryCard.className = "pay-card";
            summaryCard.innerHTML = `
                <div class="main-info">
                    <strong>Summary:</strong> Total Gross: £${totalGross.toFixed(2)}, Tax: £${totalTax.toFixed(2)}, NI: £${totalNI.toFixed(2)}, Take-home: £${totalTakeHome.toFixed(2)}
                    <button class="toggle-details" style="margin-left:10px; cursor:pointer;">+</button>
                </div>
                <div class="details" style="display:none;"></div>
            `;
            container.appendChild(summaryCard);

            const detailsDiv = summaryCard.querySelector(".details");
            const toggleBtn = summaryCard.querySelector(".toggle-details");

            entries.forEach(([date, entry]) => {
                const card = document.createElement("div");
                card.className = "pay-card";
                card.style.margin = "5px 0";

                // Main info with delete button
                const mainInfo = document.createElement("div");
                mainInfo.className = "main-info";
                mainInfo.style.display = "flex";
                mainInfo.style.justifyContent = "space-between";
                mainInfo.style.alignItems = "center";

                const entryText = document.createElement("span");
                entryText.textContent =
                  `${date} - ${formatCycle(entry.payCycle)} - Gross £${entry.gross}, Tax £${entry.incomeTax}, NI £${entry.ni}, Take-home £${entry.takeHome}`;
                mainInfo.appendChild(entryText);

                const deleteBtn = document.createElement("button");
                deleteBtn.textContent = "Delete this pay cycle";
                deleteBtn.style.marginLeft = "10px";
                deleteBtn.style.cursor = "pointer";
                deleteBtn.className = "delete-pay-btn";
                deleteBtn.addEventListener("click", () => {
                    if (!confirm("Are you sure you want to delete this pay cycle?")) return;
                    chrome.storage.local.get(["data"], (res) => {
                        const data = res.data || {};
                        delete data[date];
                        chrome.storage.local.set({ data }, () => {
                            renderPayForMonth(selectedTaxYear, month);
                        });
                    });
                });
                mainInfo.appendChild(deleteBtn);

                card.appendChild(mainInfo);
                renderEntryDetails(entry, card);
                detailsDiv.appendChild(card);
            });

            toggleBtn.addEventListener("click", () => {
                const isHidden = detailsDiv.style.display === "none";
                detailsDiv.style.display = isHidden ? "block" : "none";
                toggleBtn.textContent = isHidden ? "−" : "+";
            });
        } else {
            // Single entry
            const [date, entry] = entries[0];
            const card = document.createElement("div");
            card.className = "pay-card";

            const mainInfo = document.createElement("div");
            mainInfo.className = "main-info";
            mainInfo.style.display = "flex";
            mainInfo.style.justifyContent = "space-between";
            mainInfo.style.alignItems = "center";

            const entryText = document.createElement("span");
            entryText.textContent =
              `${date} - ${formatCycle(entry.payCycle)} - Gross £${entry.gross}, Tax £${entry.incomeTax}, NI £${entry.ni}, Take-home £${entry.takeHome}`;
            mainInfo.appendChild(entryText);

            const deleteBtn = document.createElement("button");
            deleteBtn.textContent = "Delete this pay cycle";
            deleteBtn.style.marginLeft = "10px";
            deleteBtn.style.cursor = "pointer";
            deleteBtn.className = "delete-pay-btn";
            deleteBtn.addEventListener("click", () => {
                if (!confirm("Are you sure you want to delete this pay cycle?")) return;
                chrome.storage.local.get(["data"], (res) => {
                    const data = res.data || {};
                    delete data[date];
                    chrome.storage.local.set({ data }, () => {
                        renderPayForMonth(selectedTaxYear, month);
                    });
                });
            });
            mainInfo.appendChild(deleteBtn);

            card.appendChild(mainInfo);
            renderEntryDetails(entry, card);
            container.appendChild(card);
        }
    });
}




function renderMonthlyBarChartInContainer(selectedTaxYear = null) {
    const container = document.getElementById("container");
    if (!container) return;

    // Clear current content
    container.innerHTML = "";

    // Create canvas
    const canvas = document.createElement("canvas");
    canvas.id = "monthlyBarChart";
    canvas.width = 600;
    canvas.height = 400;
    container.appendChild(canvas);

    const ctx = canvas.getContext("2d");

    chrome.storage.local.get(["data"], (res) => {
    const data = res.data || {};
    const monthlyTotals = {};

    for (let m = 1; m <= 12; m++) monthlyTotals[m] = 0;

    Object.entries(data).forEach(([date, entry]) => {
        if (selectedTaxYear && getTaxYearFromDate(date) !== selectedTaxYear) return;
        const month = new Date(date).getMonth() + 1;
        monthlyTotals[month] += entry.gross;
    });

    if (window.monthlyChart) window.monthlyChart.destroy();

    // Rearrange for tax-year order: April → March
    const calendarLabels = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const startMonthIndex = 3; // April
    const labels = calendarLabels.slice(startMonthIndex).concat(calendarLabels.slice(0, startMonthIndex));
    const chartData = Object.values(monthlyTotals).slice(startMonthIndex).concat(Object.values(monthlyTotals).slice(0, startMonthIndex));

    window.monthlyChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Gross Income (£)',
                data: chartData,
                backgroundColor: '#4CAF50'
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `£${context.raw.toFixed(2)}`;
                        }
                    }
                }
            },
            scales: { y: { beginAtZero: true } },
            onClick: function(evt, elements) {
                if (elements.length > 0) {
                    const index = elements[0].index;
                    // Adjust month for tax-year order
                    const month = ((index + 3) % 12) + 1;
                    renderPayForMonth(selectedTaxYear, month);
                    monthlyChartVisible = false;
                    document.getElementById("showMonthlyBtn").textContent = "Show Monthly Bar Chart";
                }
            }
        }
    });
});

}


// Tax year selector
document.addEventListener("DOMContentLoaded", () => {
    const selector = document.getElementById("taxYearSelector");
    if (selector) {
        chrome.storage.local.get(["data"], (res) => {
            const data = res.data || {};
            const taxYearsSet = new Set();

            Object.keys(data).forEach(date => {
                taxYearsSet.add(getTaxYearFromDate(date));
            });

            [...taxYearsSet].sort().forEach(year => {
                const option = document.createElement("option");
                option.value = year;
                option.textContent = year;
                selector.appendChild(option);
            });

            selector.value = getCurrentTaxYear();
            
            // Render data and pie chart initially
            renderSavedData(selector.value);
            renderYearlyPieChart(selector.value);

            // Reset toggle state when tax year changes
            selector.addEventListener("change", () => {
                // Reset monthly chart toggle
                monthlyChartVisible = false;
                document.getElementById("showMonthlyBtn").textContent = "Show Monthly Bar Chart";

                // Render new data & pie chart
                renderSavedData(selector.value);
                renderYearlyPieChart(selector.value);
            });
        });
    } else {
        // Fallback: just render all data if no selector
        renderSavedData();
        renderYearlyPieChart();
    }
});


function renderYearlyPieChart(selectedTaxYear = null) {
    const canvas = document.getElementById("yearlyPieChart");
    console.log('Canvas element:', canvas); // should not be null

    if (!canvas) return; // no canvas to render into

    chrome.storage.local.get(["data"], (res) => {
        const data = res.data || {};
        let totalTakeHome = 0, totalTax = 0, totalNI = 0;

        Object.entries(data).forEach(([date, entry]) => {
            if (selectedTaxYear && getTaxYearFromDate(date) !== selectedTaxYear) return;
            totalTakeHome += entry.takeHome;
            totalTax += entry.incomeTax;
            totalNI += entry.ni;
        });

        const ctx = canvas.getContext("2d");

        // Destroy previous chart if exists
        if (window.yearlyChart) window.yearlyChart.destroy();

        window.yearlyChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ['Take-home', 'Tax', 'NI'],
                datasets: [{
                    data: [totalTakeHome, totalTax, totalNI],
                    backgroundColor: ['#4caf50', '#f44336', '#2196f3'],
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.raw || 0;
                                return `${label}: £${value.toFixed(2)}`;
                            }
                        }
                    },
                    legend: {
                        position: 'bottom',
                    }
                }
            }
        });
    });
}

