export function calculateTakeHome(gross, payCycle) {
    let personalAllowance, niThreshold;
    const basicRate = 0.20;
    const higherRate = 0.40;
    const niRate = 0.08;

    // Set thresholds based on pay cycle
    switch (payCycle) {
        case "weekly":
            personalAllowance = 12570 / 52;
            niThreshold = 242;
            var upperIncomeLimit = 50270 / 52;
            break;
        case "biweekly":
            personalAllowance = 12570 / 26;
            niThreshold = 242 * 2;
            var upperIncomeLimit = 50270 / 26;
            break;
        case "fourweekly":
            personalAllowance = 12570 / 13;
            niThreshold = 242 * 4;
            var upperIncomeLimit = 50270 / 13;
            break;
        case "yearly":
            personalAllowance = 12570;
            niThreshold = 12570; // same threshold for simplicity
            var upperIncomeLimit = 50270;
            break;
        default: // monthly
            personalAllowance = 12570 / 12;
            niThreshold = 1048;
            var upperIncomeLimit = 50270 / 12;
            break;
    }

    // Income tax calculation
    let taxableIncome = Math.max(0, gross - personalAllowance);
    let incomeTax = 0;

    if (gross <= personalAllowance) {
        incomeTax = 0;
    } else if (gross <= upperIncomeLimit) {
        incomeTax = taxableIncome * basicRate;
    } else {
        const basicTaxable = upperIncomeLimit - personalAllowance;
        const higherTaxable = gross - upperIncomeLimit;
        incomeTax = basicTaxable * basicRate + higherTaxable * higherRate;
    }

    // National Insurance (flat 8% above threshold)
    let ni = 0;
    if (gross > niThreshold) {
        ni = (gross - niThreshold) * niRate;
    }

    // Final take-home
    const takeHome = gross - incomeTax - ni;

    return { incomeTax, ni, takeHome };
}
