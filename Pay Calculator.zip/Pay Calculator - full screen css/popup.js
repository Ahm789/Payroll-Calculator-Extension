import { calculateTakeHome } from "./tax.js";
document.getElementById("applyAdditionsBtn").addEventListener("click", () => {
    additionalDetails({ checkForNoAdditions: true });
});
let holidayAddedToSummary = false;
const holidays = [];
function additionalDetails({ checkForNoAdditions = true } = {}) {
    const extraDeductionsValue = parseFloat(parseExpression(document.getElementById('extraDeductions').value)) || 0;
    const extraTaxFreeValue    = parseFloat(parseExpression(document.getElementById('extraTaxFree').value)) || 0;
   // Parse holiday hours and rate
    const hours = parseExpression(document.getElementById('holidayHours').value) || 0;
    const rate  = parseExpression(document.getElementById('holidayRate').value) || 0;

    // Calculate holiday addition if totalHolidayValue is 0
    let additionsValue = parseExpression(document.getElementById("totalHolidayValue").textContent) || 0;
    if (hours > 0 && rate > 0) {
        additionsValue = hours * rate;
        // Reset the summary flag if the value has changed or same value added again
        holidayAddedToSummary = false;
        holidays.push({ hours, rate, value: additionsValue });
        renderHolidayList();
    }
    document.getElementById('holidayHours').value = '';
    document.getElementById('holidayRate').value = '';

    // Check if there is anything to add
    if (checkForNoAdditions && (additionsValue || 0) <= 0 && (extraDeductionsValue || 0) <= 0 && (extraTaxFreeValue || 0) <= 0) {
        alert("No additional value to add.");
        return;
    }

    const grossInput = document.getElementById("gross");
    let currentGross = grossInput.value.trim();

    // Only apply this if there is a holiday addition
    if (additionsValue > 0 && !holidayAddedToSummary) {
        holidayAddedToSummary = true;
        // If input is empty → just insert holiday value
        if (currentGross === "") {
            grossInput.value = additionsValue.toFixed(2);
        }
        // If ends with +, -, *, or / → append value directly
        else if (/[\+\-\*\/]$/.test(currentGross)) {
            grossInput.value = currentGross + additionsValue.toFixed(2);
        }
        // Otherwise append as +value
        else {
            grossInput.value = currentGross + " + " + additionsValue.toFixed(2);
        }
    }
    const rawGross = grossInput.value;
    const gross = parseExpression(rawGross);
    const payCycle = document.getElementById("payCycle").value;
    const resultBox = document.getElementById("result");

    if (!rawGross || isNaN(gross) || !gross) {
        resultBox.textContent = "Enter a valid number or calculation.";
        return;
    }

    const result = calculateTakeHome(gross, payCycle);

    // Only extras affect take-home here (holiday already in gross)
    // Only extras affect take-home, tax and NI remain as calculated
    const adjustedTakeHome = (result.takeHome || 0) + extraTaxFreeValue - extraDeductionsValue;

    resultBox.textContent =
        `Take-home per period: £${adjustedTakeHome.toFixed(2)} (Tax: £${result.incomeTax.toFixed(2)}, NI: £${result.ni.toFixed(2)})`;
    const summaryBox = document.getElementById("additionSummary");

    // Calculate total holiday value from the array
    const totalHolidayValue = holidays.reduce((sum, h) => sum + h.value, 0);

    // Update summary HTML
    summaryBox.innerHTML = `
        ${totalHolidayValue > 0 ? `<div class="holiday">Holiday Added: £${totalHolidayValue.toFixed(2)}</div>` : ""}
        ${extraTaxFreeValue > 0 ? `<div class="add">Tax-Free Additions: +£${extraTaxFreeValue.toFixed(2)}</div>` : ""}
        ${extraDeductionsValue > 0 ? `<div class="deduct">Extra Deductions: -£${extraDeductionsValue.toFixed(2)}</div>` : ""}
    `;


}

document.addEventListener('DOMContentLoaded', () => {
    const settingsBtn = document.getElementById('settingsDrawerBtn');
    const settingsDrawer = document.getElementById('settingsDrawer');
    const popupContainer = document.querySelector('.settings-btn-wrapper');
    const body = document.body;
    const closeSettingsBtn = document.getElementById('closeSettingsBtn');

    // Always keep drawer visible
    settingsBtn.style.display = 'block';
    body.style.width = '320px'; // default

    settingsBtn.addEventListener('click', () => {
        body.style.width = '660px'; // expand
        body.style.height = 'auto';            // height grows with content
        body.style.minHeight = '750px';        // ensures a minimum visible height

        popupContainer.style.float = 'left';
        popupContainer.style.width = '320px';
        settingsBtn.style.display = 'none';
        popupContainer.style.margin='0';
        settingsDrawer.style.display = 'block';
        settingsDrawer.right = '270px';
    });
    closeSettingsBtn.addEventListener('click', () => {
        // Shrink body back
        body.style.width = '320px';      // original width
        body.style.height = 'auto';      // let height adjust
        body.style.minHeight = '';       // remove minHeight

        popupContainer.style.float = ''; // reset float
        popupContainer.style.width = '100%'; // full width again
        popupContainer.style.margin = '';
        
        settingsDrawer.style.display = 'none';
        settingsBtn.style.display = 'block';
    });
    const addHolidayBtn = document.getElementById('addHolidayBtn');

    addHolidayBtn.addEventListener('click', () => {
        holidayAddedToSummary  = false;
        const hours = parseExpression(document.getElementById('holidayHours').value);
        const rate  = parseExpression(document.getElementById('holidayRate').value);

        if (isNaN(hours) || hours <= 0 || isNaN(rate) || rate <= 0) {
            alert("Enter valid hours and hourly rate.");
            return;
        }

        const value = hours * rate;
        holidays.push({ hours, rate, value });

        renderHolidayList();
        document.getElementById('holidayHours').value = '';
        document.getElementById('holidayRate').value = '';
    });

    
});
function renderHolidayList() {
        const list = document.getElementById("holidayList");
        list.innerHTML = "";

        let totalHours = 0;
        let totalValue = 0;

        holidays.forEach((h, index) => {
            const li = document.createElement("li");
            li.style.display = "flex";
            li.style.marginLeft = "-40px";
            li.style.alignItems = "center";
            
            li.style.marginBottom = "4px";
            li.style.width = "100%";

            // Holiday hours
            const hoursSpan = document.createElement("span");
            hoursSpan.textContent = `${h.hours} hours`;
            hoursSpan.style.marginRight = "8px";
            hoursSpan.style.minWidth = "60px";

            // Hourly rate
            const rateSpan = document.createElement("span");
            rateSpan.textContent = `£${h.rate.toFixed(2)}/hr`;
            rateSpan.style.marginRight = "8px";
            rateSpan.style.minWidth = "60px";
            rateSpan.style.whiteSpace = "nowrap";

            // Value
            const valueSpan = document.createElement("span");
            valueSpan.textContent = `= £${h.value.toFixed(2)}`;
            valueSpan.style.marginRight = "8px";
            valueSpan.style.whiteSpace = "nowrap";

            const removeBtn = document.createElement("button");
            removeBtn.textContent = "×";
            removeBtn.title = "Remove holiday";

            // Inline, matches text height
            removeBtn.style.display = "inline-flex";
            removeBtn.style.alignItems = "center";
            removeBtn.style.justifyContent = "center";
            removeBtn.style.padding = "0";        // remove extra space
            removeBtn.style.marginLeft = "auto";  // push to right
            removeBtn.style.cursor = "pointer";
            removeBtn.style.border = "none";
            removeBtn.style.background = "none";
            removeBtn.style.color = "#c00";
            removeBtn.style.fontWeight = "bold";
            removeBtn.style.fontSize = "14px";
            removeBtn.style.marginTop = "0px";
            removeBtn.style.lineHeight = "1";     // ensures vertical alignment with text
            removeBtn.style.borderRadius = "3px";

            removeBtn.addEventListener("click", () => {
                holidays.splice(index, 1);
                renderHolidayList();
            });


            li.appendChild(hoursSpan);
            li.appendChild(rateSpan);
            li.appendChild(valueSpan);
            li.appendChild(removeBtn);
            list.appendChild(li);

            totalHours += h.hours;
            totalValue += h.value;
        });

        document.getElementById("totalHolidayHours").textContent = totalHours.toFixed(1);
        document.getElementById("totalHolidayValue").textContent = totalValue.toFixed(2);
    }
const extraDeductionsInput = document.getElementById("extraDeductions");

chrome.storage.local.get("lastExtraDeductions", (res) => {
    if (res.lastExtraDeductions !== undefined) {
        extraDeductionsInput.value = res.lastExtraDeductions;
    }
});
extraDeductionsInput.addEventListener("input", () => {
    const value = extraDeductionsInput.value.trim();
    chrome.storage.local.set({ lastExtraDeductions: value });
});

// Get the input element
const hourlyInput = document.getElementById("hourlyRate");

// 1️⃣ Load saved value when popup opens
chrome.storage.local.get("lastHourlyRate", (res) => {
    if (res.lastHourlyRate) {
        hourlyInput.value = res.lastHourlyRate;
    }
});

// 2️⃣ Save value when user presses Enter
hourlyInput.addEventListener("input", () => {
    const rate = hourlyInput.value.trim();
    chrome.storage.local.set({ lastHourlyRate: rate });
});
const holidayRateInput = document.getElementById("holidayRate");

// 1️⃣ Load saved value when popup opens
chrome.storage.local.get("lastHolidayRate", (res) => {
    if (res.lastHolidayRate) {
        holidayRateInput.value = res.lastHolidayRate;
    }
});

// 2️⃣ Save value whenever user changes it
holidayRateInput.addEventListener("input", () => {
    const rate = holidayRateInput.value.trim();
    chrome.storage.local.set({ lastHolidayRate: rate });
});


// Switch between screens
document.getElementById("switchToHourly").addEventListener("click", () => {
    document.getElementById("mainCalc").style.display = "none";
    document.getElementById("hourlyCalc").style.display = "block";
    document.getElementById("switchToHourly").style.display = "none";
    document.getElementById("switchToMain").style.display = "inline-block";
});

document.getElementById("switchToMain").addEventListener("click", () => {
    document.getElementById("mainCalc").style.display = "block";
    document.getElementById("hourlyCalc").style.display = "none";
    document.getElementById("switchToHourly").style.display = "inline-block";
    document.getElementById("switchToMain").style.display = "none";
});

// HOURLY SHIFT SYSTEM
let shifts = []; // Each shift is { hours: number, rate: number }


//Multiple formats: "36", "36*4", "10x3"
function parseExpression(input) {
    input = input.replace(/x/gi, "*").replace(/\s+/g, "");
    const outputQueue = [];
    const operatorStack = [];
    const ops = { "+": 1, "-": 1, "*": 2, "/": 2 };

    const tokens = input.match(/(\d+\.?\d*|\+|\-|\*|\/|\(|\))/g);
    if (!tokens) return NaN;

    for (let token of tokens) {
        if (!isNaN(token)) {
            outputQueue.push(parseFloat(token));
        } else if (token in ops) {
            while (
                operatorStack.length &&
                ops[operatorStack[operatorStack.length - 1]] >= ops[token]
            ) {
                outputQueue.push(operatorStack.pop());
            }
            operatorStack.push(token);
        } else if (token === "(") {
            operatorStack.push(token);
        } else if (token === ")") {
            while (operatorStack.length && operatorStack[operatorStack.length - 1] !== "(") {
                outputQueue.push(operatorStack.pop());
            }
            operatorStack.pop(); // Remove '('
        }
    }

    while (operatorStack.length) {
        outputQueue.push(operatorStack.pop());
    }

    // Evaluate RPN
    const stack = [];
    for (let token of outputQueue) {
        if (typeof token === "number") stack.push(token);
        else {
            const b = stack.pop();
            const a = stack.pop();
            switch (token) {
                case "+": stack.push(a + b); break;
                case "-": stack.push(a - b); break;
                case "*": stack.push(a * b); break;
                case "/": stack.push(a / b); break;
            }
        }
    }

    return stack[0];
}





// Usage in the addShift button
document.getElementById("addShiftBtn").addEventListener("click", () => {
    const rawHours = document.getElementById("shiftHours").value;
    const rate = parseFloat(parseExpression(document.getElementById("hourlyRate").value)) || 0;

    if (!rawHours || !rate || rate <= 0) {
        alert("Enter valid hours and hourly rate.");
        return;
    }

    const hours = parseExpression(rawHours);

    if (isNaN(hours) || hours <= 0) {
        alert("Enter valid hours (e.g., 36, 36*4, 10x3).");
        return;
    }

    shifts.push({ hours, rate });

    renderShiftList();
    document.getElementById("shiftHours").value = "";

    saveHourlyState();
});





function renderShiftList() {
    const list = document.getElementById("shiftList");
    list.innerHTML = "";

    // Recalculate total weekly hours from shifts
    let weeklyHours = shifts.reduce((sum, s) => sum + s.hours, 0);

    shifts.forEach((s, index) => {
        const li = document.createElement("li");
        li.style.display = "flex";
        li.style.alignItems = "center";
        li.style.justifyContent = "flex-start"; // align left
        li.style.marginBottom = "4px";
        li.style.width = "100%";

        // Shift hours
        const hoursSpan = document.createElement("span");
        hoursSpan.textContent = `${s.hours} hours`;
        hoursSpan.style.marginRight = "8px";
        hoursSpan.style.minWidth = "60px"; // fixed width to prevent shifting

        // Hourly rate
        const rateSpan = document.createElement("span");
        rateSpan.textContent = `£${s.rate.toFixed(2)}/hr`;
        rateSpan.style.marginRight = "8px";
        rateSpan.style.minWidth = "80px"; // fixed width to align all rates
        rateSpan.style.whiteSpace = "nowrap";

        // Remove button
        const removeBtn = document.createElement("button");
        removeBtn.textContent = "×";
        removeBtn.title = "Remove shift";
        removeBtn.style.width = "32px";
        removeBtn.style.height = "32px";
        removeBtn.style.fontSize = "1.2em";
        removeBtn.style.cursor = "pointer";
        removeBtn.style.border = "none";
        removeBtn.style.background = "#f5f5f5";
        removeBtn.style.color = "#c00";
        removeBtn.style.fontWeight = "bold";
        removeBtn.style.borderRadius = "4px";
        removeBtn.style.display = "flex";
        removeBtn.style.alignItems = "center";
        removeBtn.style.justifyContent = "center";

        removeBtn.addEventListener("click", () => {
            shifts.splice(index, 1);
            renderShiftList();
            saveHourlyState();
        });

        li.appendChild(hoursSpan);
        li.appendChild(rateSpan);
        li.appendChild(removeBtn);
        list.appendChild(li);
    });


    // Update total weekly hours
    document.getElementById("totalHours").textContent = weeklyHours.toFixed(1);
}

document.getElementById("calcHourlyBtn").addEventListener("click", () => {
    let totalPay = 0;

    // 1️⃣ Calculate from added shifts
    if (shifts.length > 0) {
        totalPay = shifts.reduce((sum, s) => sum + s.hours * s.rate, 0);
    }

    // 2️⃣ Include the pending shift typed in the input
    const rawHours = document.getElementById("shiftHours").value;
    const pendingRate = Number(document.getElementById("hourlyRate").value);

    const pendingHours = parseExpression(rawHours); // use the parser

    if (!isNaN(pendingHours) && pendingHours > 0 && pendingRate > 0) {
        totalPay += pendingHours * pendingRate;
        // Do NOT add to shifts array — just use it for calculation
    }

    // 3️⃣ If totalPay is still 0, show a message
    if (totalPay === 0) {
        alert("Please enter hours and hourly rate to calculate.");
        return;
    }

    // 4️⃣ Fill main gross input with calculated total pay
    document.getElementById("gross").value = totalPay.toFixed(2);

    // 5️⃣ Switch back to main calculator view
    document.getElementById("mainCalc").style.display = "block";
    document.getElementById("hourlyCalc").style.display = "none";
    document.getElementById("switchToHourly").style.display = "inline-block";
    document.getElementById("switchToMain").style.display = "none";

    // Optional: clear the hourly shift input
    document.getElementById("shiftHours").value = "";
});


// MAIN PAY CALCULATOR
document.getElementById("calcBtn").addEventListener("click", () => {
    const rawGross = document.getElementById("gross").value;
    const gross = parseExpression(rawGross);

    const payCycle = document.getElementById("payCycle").value;
    const resultBox = document.getElementById("result");
    
    // Save current gross and payCycle to storage
    chrome.storage.local.set({ lastGross: gross, lastPayCycle: payCycle });
    if (!rawGross || isNaN(gross)) {
        resultBox.textContent = "Enter a valid number or calculation.";
        return;
    }


    if (!gross) {
        resultBox.textContent = "Please enter a valid number.";
        return;
    }

    const result = calculateTakeHome(gross, payCycle);

    resultBox.textContent =
        `Take-home per period: £${result.takeHome.toFixed(2)} (Tax: £${result.incomeTax.toFixed(2)}, NI: £${result.ni.toFixed(2)})`;
    additionalDetails({ checkForNoAdditions: false });
});

document.getElementById("saveBtn").addEventListener("click", () => {
    const rawGross = document.getElementById("gross").value;
    const gross = parseExpression(rawGross);

    const payCycle = document.getElementById("payCycle").value;
    const payDate = document.getElementById("payDate").value; // YYYY-MM-DD

    if (!payDate) {
        alert("Please select a pay date.");
        return;
    }

    const { incomeTax, ni, takeHome } = calculateTakeHome(gross, payCycle);
    // Build holiday summary
    const holidayRecords = holidays.map(h => ({
        hours: h.hours,
        rate: h.rate,
        pay: Number((h.hours * h.rate).toFixed(2))
    }));

    const totalHolidayHours = holidayRecords.reduce((sum, h) => sum + h.hours, 0);
    const totalHolidayPay   = holidayRecords.reduce((sum, h) => sum + h.pay, 0);
    const extraDeductionsValue = parseFloat(parseExpression(document.getElementById('extraDeductions').value)) || 0;
    const extraTaxFreeValue    = parseFloat(parseExpression(document.getElementById('extraTaxFree').value)) || 0;



    chrome.storage.local.get(["data"], (res) => {
        const data = res.data || {};

        // Save main pay info AND shifts
        data[payDate] = {
            payCycle: payCycle, // <<< NEW
            gross: Number(gross.toFixed(2)),
            incomeTax: Number(incomeTax.toFixed(2)),
            ni: Number(ni.toFixed(2)),
            takeHome: Number((gross - incomeTax - ni - extraDeductionsValue + extraTaxFreeValue).toFixed(2)),
            extraDeductions: Number(extraDeductionsValue.toFixed(2)), // <<< ADDED
            extraTaxFree: Number(extraTaxFreeValue.toFixed(2)),       // <<< ADDED
            

            shifts: shifts.map(s => ({
                hours: s.hours,
                rate: s.rate,
                gross: Number((s.hours * s.rate).toFixed(2))
            })),

            holidays: {
                records: holidayRecords,
                totalHours: Number(totalHolidayHours.toFixed(2)),
                totalPay: Number(totalHolidayPay.toFixed(2))
            }
        };

        


        chrome.storage.local.set({ data }, () => {
            alert(`Pay and shifts for ${payDate} saved!`);
            renderSavedData();
        });
    });
});





